# Simple Useless Python Package

Only used for application packaging test.
Don't use it ;-)

## Usage:
```
$ python -m universal_answer
```