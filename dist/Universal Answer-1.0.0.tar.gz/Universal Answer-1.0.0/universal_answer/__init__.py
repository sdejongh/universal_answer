__program__ = "Universal Answer"
__version__ = "1.0"
__author__ = "Steve De Jongh"