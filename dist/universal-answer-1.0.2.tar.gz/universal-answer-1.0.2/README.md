# Simple Useless Python Package

Only used for application packaging test.

## Usage:
```
$ python -m universal_answer
```